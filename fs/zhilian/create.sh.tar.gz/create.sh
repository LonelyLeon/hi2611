#!/bin/sh

if [ -f $1 ] ;then
	echo "Must set lib dir"
	exit -1
fi

#lib ln
ln -sf $1/lib/libblkid.so.1.1.0 ./lib/libblkid.so.1.1.0
ln -sf $1/lib/libmount.so.1.1.0 ./lib/libmount.so.1.1.0
ln -sf $1/lib/libuuid.so.1.3.0 ./lib/libuuid.so.1.3.0


#usr/lib ln

ln -sf $1/lib/ld-2.23.so ./usr/ld-2.23.so
ln -sf $1/lib/libdirect-1.7.so.7.0.0 ./usr/libdirect-1.7.so.7.0.0 
ln -sf $1/lib/libdirectfb-1.7.so.7.0.0 ./usr/libdirectfb-1.7.so.7.0.0 
ln -sf $1/lib/libffi.so.6.0.4 ./usr/libffi.so.6.0.4 
ln -sf $1/lib/libfusion-1.7.so.7.0.0 ./usr/libfusion-1.7.so.7.0.0  
ln -sf $1/lib/libgio-2.0.so.0.5000.2 ./usr/libgio-2.0.so.0.5000.2 
ln -sf $1/lib/libglib-2.0.so.0.5000.2 ./usr/libglib-2.0.so.0.5000.2 
ln -sf $1/lib/libgmodule-2.0.so.0.5000.2 ./usr/libgmodule-2.0.so.0.5000.2 
ln -sf $1/lib/libgobject-2.0.so.0.5000.2 ./usr/libgobject-2.0.so.0.5000.2 
ln -sf $1/lib/libgthread-2.0.so.0.5000.2 ./usr/libgthread-2.0.so.0.5000.2 
ln -sf $1/lib/libjson-glib-1.0.so.0.1400.2 ./usr/libjson-glib-1.0.so.0.1400.2 
ln -sf $1/lib/libpcre.so.1.2.8 ./usr/libpcre.so.1.2.8 
ln -sf $1/lib/libpixman-1.so.0.34.0 ./usr/libpixman-1.so.0.34.0 
ln -sf $1/lib/libsoup-2.4.so.1.8.0 ./usr/libsoup-2.4.so.1.8.0 
ln -sf $1/lib/libsqlite3.so.0.8.6 ./usr/libsqlite3.so.0.8.6 
ln -sf $1/lib/libxml2.so.2.9.4 ./usr/libxml2.so.2.9.4 
